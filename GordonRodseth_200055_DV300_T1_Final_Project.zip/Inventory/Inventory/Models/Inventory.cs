﻿using System;
using System.Collections.Generic;
namespace Inventory.Models
{
    public class Inventory
    {
        
    }
}
